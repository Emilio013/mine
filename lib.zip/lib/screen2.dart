// ignore_for_file: file_names

import 'package:crud_firebase/main.dart';
import 'package:crud_firebase/screen3.dart';
import 'package:flutter/material.dart';

void main() => runApp(const Screen2());

class Screen2 extends StatelessWidget {
  const Screen2({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Material App',
        home: Scaffold(
            appBar: AppBar(
              title: const Text('Material App Bar'),
            ),
            body: Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const Screen3()));
                        },
                        child: const Text("presioname"))
                  ]),
            )));
  }
}
