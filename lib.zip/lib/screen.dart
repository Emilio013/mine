import 'package:crud_firebase/Screen2.dart';
import 'package:flutter/material.dart';

void main() => runApp(const Screen());

class Screen extends StatelessWidget {
  const Screen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Material App',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('dashboard'),
        ),
        body: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => const Screen2()));
                },
                child: const Text("presioname"))
          ],
        )),
      ),
    );
  }
}
