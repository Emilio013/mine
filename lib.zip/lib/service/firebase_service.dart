import 'package:cloud_firestore/cloud_firestore.dart';

FirebaseFirestore db = FirebaseFirestore.instance;

Future<List> gethola() async {
  List hola = [];

  CollectionReference collectionReferencehola = db.collection('hola');
  QuerySnapshot queryhola = await collectionReferencehola.get();

  queryhola.docs.forEach((documento) {
    hola.add(documento.data());
  });

  await Future.delayed(const Duration(seconds: 3));

  return hola;
}
